zip -r9 ../lambda_query.zip *
