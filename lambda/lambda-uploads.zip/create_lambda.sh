zip -r9 ../lambda-uploads.zip *
